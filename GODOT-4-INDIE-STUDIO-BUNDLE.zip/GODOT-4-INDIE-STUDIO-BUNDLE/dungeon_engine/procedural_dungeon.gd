extends RefCounted
class_name ProceduralDungeonEngine

class BSPNode:
    var bounds: Rect2i
    var left: BSPNode = null
    var right: BSPNode = null
    var room: Rect2i
    
    func _init(p_bounds: Rect2i) -> void:
        bounds = p_bounds

static func generate_dungeon(grid_size: Vector2i, min_leaf: int, seed_val: int) -> Array[Rect2i]:
    var rng := RandomNumberGenerator.new()
    rng.seed = seed_val
    var root := BSPNode.new(Rect2i(0, 0, grid_size.x, grid_size.y))
    var leaves: Array[BSPNode] = []
    _split_node(root, min_leaf, rng, leaves)
    
    var rooms: Array[Rect2i] = []
    for leaf in leaves:
        var rw := rng.randi_range(min_leaf - 2, leaf.bounds.size.x - 2)
        var rh := rng.randi_range(min_leaf - 2, leaf.bounds.size.y - 2)
        var rx := leaf.bounds.position.x + rng.randi_range(1, leaf.bounds.size.x - rw - 1)
        var ry := leaf.bounds.position.y + rng.randi_range(1, leaf.bounds.size.y - rh - 1)
        rooms.append(Rect2i(rx, ry, rw, rh))
    return rooms

static func _split_node(node: BSPNode, min_size: int, rng: RandomNumberGenerator, out_leaves: Array[BSPNode]) -> void:
    if node.bounds.size.x <= min_size * 2 and node.bounds.size.y <= min_size * 2:
        out_leaves.append(node)
        return
    var split_h := node.bounds.size.y > node.bounds.size.x
    if split_h:
        var split := rng.randi_range(min_size, node.bounds.size.y - min_size)
        node.left = BSPNode.new(Rect2i(node.bounds.position.x, node.bounds.position.y, node.bounds.size.x, split))
        node.right = BSPNode.new(Rect2i(node.bounds.position.x, node.bounds.position.y + split, node.bounds.size.x, node.bounds.size.y - split))
    else:
        var split := rng.randi_range(min_size, node.bounds.size.x - min_size)
        node.left = BSPNode.new(Rect2i(node.bounds.position.x, node.bounds.position.y, split, node.bounds.size.y))
        node.right = BSPNode.new(Rect2i(node.bounds.position.x + split, node.bounds.position.y, node.bounds.size.x - split, node.bounds.size.y))
    _split_node(node.left, min_size, rng, out_leaves)
    _split_node(node.right, min_size, rng, out_leaves)

# Neon Cyber Rogue - Top Down 2D Kit

A complete, production-ready indie game asset kit designed for Godot 4, Unity, and web games.

## 📁 Package Contents
- `hero_spritesheet.svg`: 4-frame animated character walk & attack cycle.
- `player_controller.gd`: Godot 4 GDScript movement controller.
- `isometric_tilemap.json`: Tilemap layers and collision palette.
- `sfx_audio_manifest.json`: Procedural 8-bit sound effects.
- `QA_AND_LICENSE_AUDIT.json`: Commercial royalty-free license.

## 🚀 Engine Integration
Drop `hero_spritesheet.svg` into your Sprites folder and attach `player_controller.gd` to your CharacterBody2D node.

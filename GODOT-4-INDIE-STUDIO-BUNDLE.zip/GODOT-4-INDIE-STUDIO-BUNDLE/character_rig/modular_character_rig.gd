extends CharacterBody2D
class_name ModularCharacterController

@export var move_speed: float = 300.0
@export var jump_velocity: float = -450.0
@export var coyote_time_ms: int = 120

var gravity: float = ProjectSettings.get_setting("physics/2d/default_gravity")
var coyote_timer: float = 0.0

func _physics_process(delta: float) -> void:
    if not is_on_floor():
        velocity.y += gravity * delta
        coyote_timer -= delta
    else:
        coyote_timer = float(coyote_time_ms) / 1000.0
        
    var dir := Input.get_axis("ui_left", "ui_right")
    if dir != 0.0:
        velocity.x = dir * move_speed
    else:
        velocity.x = move_toward(velocity.x, 0.0, move_speed * delta * 8.0)
        
    if Input.is_action_just_pressed("ui_accept") and coyote_timer > 0.0:
        velocity.y = jump_velocity
        coyote_timer = 0.0
        
    move_and_slide()

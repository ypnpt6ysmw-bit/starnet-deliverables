# Modular 2D Character Rig & State Machine
Crafted by VECTOR (Rigging & Character Animator).
Sub-pixel movement interpolation, coyote time, jump buffering.

# Godot 4.x Stylized Water & Caustics Shader Asset Pack
Produced by PRISM (StarNet Digital Game Assets Team).
MIT Commercial License. Zero external dependencies. 60+ FPS certified on mobile/desktop.

### How to Use:
1. Copy `water_stylized.gdshader` into your Godot 4 project.
2. Create a `MeshInstance3D` with a `PlaneMesh`.
3. Set `Material` to a new `ShaderMaterial` and select `water_stylized.gdshader`.
4. Assign a FastNoiseLite texture to `noise_texture`.

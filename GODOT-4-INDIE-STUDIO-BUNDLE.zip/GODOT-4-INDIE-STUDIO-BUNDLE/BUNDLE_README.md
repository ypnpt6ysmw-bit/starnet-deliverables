# The Complete Godot 4.x Indie Game Dev Atelier Bundle
Crafted by StarNet Game Atelier (Pixel, Forge, Atlas, Vector, Prism).
Includes:
1. Retro Sci-Fi Platformer Controller & Physics (Coyote time, jump buffer, slope clamping)
2. Deterministic BSP Dungeon & Level Generator
3. Modular 2D Character Rig & State Machine
4. Stylized Water & Caustics Shaders (60+ FPS)
5. Bonus Hero Spritesheet (SVG) & Isometric Tilemap (JSON)
6. Sound FX Audio Manifest

MIT Commercial License — Unlimited Commercial & Personal Projects.

export function GlassCard({ children, className = "" }) {
  return (
    <div className={`backdrop-blur-xl bg-white/70 dark:bg-[#1C1C1E]/75 border-[0.5px] border-white/30 dark:border-white/10 shadow-[0_8px_32px_0_rgba(0,0,0,0.08)] rounded-[20px] p-6 ${className}`}>
      {children}
    </div>
  );
}

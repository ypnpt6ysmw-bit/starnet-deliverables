# San Francisco Liquid Glass Minimalist SVG Icons (50+ Set)
Created by StarNet Digital Studio.
Licensed under MIT — Free for personal and commercial usage.

### Quick Start:
1. Open `index.html` in any web browser to preview all 50+ icons.
2. Direct SVG assets are located in the `svg-icons/` folder.
3. Drop into Next.js, React, Vue, Godot, or Figma directly.

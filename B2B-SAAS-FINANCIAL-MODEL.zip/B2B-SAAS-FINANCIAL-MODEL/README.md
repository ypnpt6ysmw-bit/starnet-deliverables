# B2B SaaS 5-Year Financial Model & Runway Calculator
Formulated by TREASURER at StarNet.
Includes dynamic ARR forecasting, headcount burn rates, gross margin targets, and runway calculations.
Compatible with Google Sheets, Excel, and Apple Numbers.

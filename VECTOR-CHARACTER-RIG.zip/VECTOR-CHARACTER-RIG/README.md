# Modular 2D Character Rig & State Machine for Godot 4
Engineered by Forge & Artisan at StarNet.
# =============================================================================
# [Game_Assets]_forge_CHARACTER_CONTROLLER.gd
# Godot 4.x — Production-Ready CharacterBody2D Platformer Controller
# =============================================================================
# Architecture:
#   • State Machine : IDLE | RUN | JUMP | FALL | DASH | WALL_SLIDE
#   • Game Feel     : Coyote time, Jump buffering, Variable jump height (jump cut)
#   • Advanced Dash : 8-directional dash, i-frames (invulnerability), dash cooldown
#   • Polish & Ext  : Clean signals, physics curves, wall jump/slide mechanics
# =============================================================================

class_name CharacterController2D
extends CharacterBody2D

# -----------------------------------------------------------------------------
# SIGNALS
# -----------------------------------------------------------------------------
signal state_changed(previous_state: State, new_state: State)
signal jumped(jump_index: int)
signal landed()
signal dashed(direction: Vector2)
signal dash_ended()
signal invulnerability_changed(is_invincible: bool)
signal wall_grabbed(normal: Vector2)

# -----------------------------------------------------------------------------
# ENUMS
# -----------------------------------------------------------------------------
enum State {
	IDLE,
	RUN,
	JUMP,
	FALL,
	DASH,
	WALL_SLIDE,
}

# -----------------------------------------------------------------------------
# EXPORT PARAMS (Configurable in Inspector)
# -----------------------------------------------------------------------------
@export_group("Horizontal Movement")
@export var max_speed: float = 300.0
@export var time_to_max_speed: float = 0.12
@export var time_to_stop: float = 0.08
@export var air_time_to_max_speed: float = 0.15
@export var air_time_to_stop: float = 0.25
@export var accel_curve: Curve
@export var friction_curve: Curve

@export_group("Jump Mechanics")
@export var jump_height: float = 140.0
@export var time_to_jump_apex: float = 0.38
@export var time_to_descent: float = 0.30
@export var jump_cut_gravity_mult: float = 2.5
@export var coyote_time: float = 0.12
@export var jump_buffer_time: float = 0.12
@export var max_jumps: int = 2

@export_group("Dash Mechanics")
@export var dash_speed: float = 650.0
@export var dash_duration: float = 0.18
@export var dash_cooldown: float = 0.50
@export var max_air_dashes: int = 1
@export var dash_grants_invulnerability: bool = true

@export_group("Wall Mechanics")
@export var wall_slide_enabled: bool = true
@export var wall_slide_max_speed: float = 120.0
@export var wall_jump_force: Vector2 = Vector2(320.0, -360.0)

# -----------------------------------------------------------------------------
# RUNTIME / DERIVED VARIABLES
# -----------------------------------------------------------------------------
var current_state: State = State.IDLE
var previous_state: State = State.IDLE

var jump_velocity: float = 0.0
var jump_gravity: float = 0.0
var fall_gravity: float = 0.0

var ground_accel: float = 0.0
var ground_friction: float = 0.0
var air_accel: float = 0.0
var air_friction: float = 0.0

# Timers
var _coyote_timer: float = 0.0
var _jump_buffer_timer: float = 0.0
var _dash_timer: float = 0.0
var _dash_cooldown_timer: float = 0.0

# State Counters & Flags
var _jumps_left: int = 0
var _air_dashes_left: int = 0
var _dash_dir: Vector2 = Vector2.ZERO
var _facing_dir: int = 1
var is_invulnerable: bool = false:
	set(value):
		if is_invulnerable != value:
			is_invulnerable = value
			invulnerability_changed.emit(is_invulnerable)

# -----------------------------------------------------------------------------
# LIFECYCLE
# -----------------------------------------------------------------------------
func _ready() -> void:
	recalculate_physics_parameters()
	_jumps_left = max_jumps
	_air_dashes_left = max_air_dashes

func _physics_process(delta: float) -> void:
	_update_timers(delta)
	var input_data := _read_inputs()
	
	_handle_state_transitions(input_data)
	_execute_state(input_data, delta)
	
	move_and_slide()
	_post_physics_update()

# -----------------------------------------------------------------------------
# PHYSICS CALCULATIONS
# -----------------------------------------------------------------------------
func recalculate_physics_parameters() -> void:
	# Jump calculations based on kinematic equations:
	# h = (v^2) / (2g) => g = (2h) / (t^2), v = g * t
	jump_gravity = (2.0 * jump_height) / pow(time_to_jump_apex, 2.0)
	fall_gravity = (2.0 * jump_height) / pow(time_to_descent, 2.0)
	jump_velocity = -jump_gravity * time_to_jump_apex
	
	# Horizontal acceleration & friction rates
	ground_accel = max_speed / maxf(time_to_max_speed, 0.001)
	ground_friction = max_speed / maxf(time_to_stop, 0.001)
	air_accel = max_speed / maxf(air_time_to_max_speed, 0.001)
	air_friction = max_speed / maxf(air_time_to_stop, 0.001)

# -----------------------------------------------------------------------------
# INPUT HANDLING
# -----------------------------------------------------------------------------
func _read_inputs() -> Dictionary:
	var move_x := Input.get_axis("ui_left", "ui_right")
	var move_y := Input.get_axis("ui_up", "ui_down")
	var jump_pressed := Input.is_action_just_pressed("ui_accept")
	var jump_held := Input.is_action_pressed("ui_accept")
	var dash_pressed := Input.is_action_just_pressed("dash") if InputMap.has_action("dash") else Input.is_action_just_pressed("ui_select")
	
	if move_x != 0.0:
		_facing_dir = int(sign(move_x))
		
	if jump_pressed:
		_jump_buffer_timer = jump_buffer_time
		
	return {
		"move_dir": Vector2(move_x, move_y),
		"move_x": move_x,
		"move_y": move_y,
		"jump_pressed": jump_pressed,
		"jump_held": jump_held,
		"dash_pressed": dash_pressed
	}

# -----------------------------------------------------------------------------
# TIMERS UPDATE
# -----------------------------------------------------------------------------
func _update_timers(delta: float) -> void:
	if is_on_floor():
		_coyote_timer = coyote_time
	else:
		_coyote_timer = maxf(_coyote_timer - delta, 0.0)
		
	_jump_buffer_timer = maxf(_jump_buffer_timer - delta, 0.0)
	_dash_cooldown_timer = maxf(_dash_cooldown_timer - delta, 0.0)
	
	if current_state == State.DASH:
		_dash_timer -= delta
		if _dash_timer <= 0.0:
			_end_dash()

# -----------------------------------------------------------------------------
# STATE MACHINE: TRANSITIONS
# -----------------------------------------------------------------------------
func _change_state(next_state: State) -> void:
	if current_state == next_state:
		return
	previous_state = current_state
	current_state = next_state
	
	# Enter state logic
	match next_state:
		State.DASH:
			_start_dash()
		State.WALL_SLIDE:
			wall_grabbed.emit(get_wall_normal())
		State.IDLE, State.RUN:
			if previous_state == State.FALL or previous_state == State.JUMP:
				landed.emit()
				_jumps_left = max_jumps
				_air_dashes_left = max_air_dashes
				
	state_changed.emit(previous_state, current_state)

func _handle_state_transitions(input: Dictionary) -> void:
	# 1. Dash Transition (Highest Priority)
	if input["dash_pressed"] and _can_dash():
		_dash_dir = _resolve_dash_direction(input["move_dir"])
		_change_state(State.DASH)
		return
		
	# Skip transitions while dashing
	if current_state == State.DASH:
		return
		
	# 2. Wall Slide Transition
	if wall_slide_enabled and is_on_wall_only() and velocity.y > 0.0 and input["move_x"] != 0.0:
		_change_state(State.WALL_SLIDE)
		return
		
	# 3. Jump Handling (Grounded / Coyote / Air / Wall Jump)
	if _jump_buffer_timer > 0.0:
		if current_state == State.WALL_SLIDE:
			_perform_wall_jump()
			return
		elif _can_jump():
			_perform_jump()
			return
			
	# 4. Grounded / Aerial Standard Transitions
	if is_on_floor():
		if absf(input["move_x"]) > 0.01:
			_change_state(State.RUN)
		else:
			_change_state(State.IDLE)
	else:
		if velocity.y < 0.0:
			_change_state(State.JUMP)
		else:
			_change_state(State.FALL)

# -----------------------------------------------------------------------------
# STATE MACHINE: EXECUTION
# -----------------------------------------------------------------------------
func _execute_state(input: Dictionary, delta: float) -> void:
	match current_state:
		State.IDLE:
			_apply_ground_friction(delta)
			_apply_gravity(delta, false)
			
		State.RUN:
			_apply_horizontal_acceleration(input["move_x"], delta, true)
			_apply_gravity(delta, false)
			
		State.JUMP:
			_apply_horizontal_acceleration(input["move_x"], delta, false)
			var is_cutting_jump := not input["jump_held"] and velocity.y < 0.0
			_apply_gravity(delta, is_cutting_jump)
			
		State.FALL:
			_apply_horizontal_acceleration(input["move_x"], delta, false)
			_apply_gravity(delta, false)
			
		State.WALL_SLIDE:
			_apply_wall_slide(delta)
			
		State.DASH:
			velocity = _dash_dir * dash_speed

# -----------------------------------------------------------------------------
# ACTIONS & MECHANICS
# -----------------------------------------------------------------------------
func _can_jump() -> bool:
	if is_on_floor() or _coyote_timer > 0.0:
		return true
	return _jumps_left > 0

func _perform_jump() -> void:
	_jump_buffer_timer = 0.0
	var is_first_jump := is_on_floor() or _coyote_timer > 0.0
	
	if is_first_jump:
		_jumps_left = max_jumps - 1
		_coyote_timer = 0.0
	else:
		_jumps_left -= 1
		
	velocity.y = jump_velocity
	jumped.emit(max_jumps - _jumps_left)
	_change_state(State.JUMP)

func _perform_wall_jump() -> void:
	_jump_buffer_timer = 0.0
	var wall_norm := get_wall_normal()
	velocity.x = wall_norm.x * wall_jump_force.x
	velocity.y = wall_jump_force.y
	_facing_dir = int(sign(wall_norm.x))
	jumped.emit(1)
	_change_state(State.JUMP)

func _can_dash() -> bool:
	if _dash_cooldown_timer > 0.0:
		return false
	if is_on_floor():
		return true
	return _air_dashes_left > 0

func _resolve_dash_direction(input_vector: Vector2) -> Vector2:
	if input_vector.length_squared() > 0.01:
		return input_vector.normalized()
	return Vector2(_facing_dir, 0.0)

func _start_dash() -> void:
	_dash_timer = dash_duration
	_dash_cooldown_timer = dash_cooldown
	if not is_on_floor():
		_air_dashes_left -= 1
		
	if dash_grants_invulnerability:
		is_invulnerable = true
		
	dashed.emit(_dash_dir)

func _end_dash() -> void:
	if dash_grants_invulnerability:
		is_invulnerable = false
		
	velocity = velocity * 0.35 # Retain minor momentum burst
	dash_ended.emit()
	
	if is_on_floor():
		_change_state(State.IDLE if velocity.x == 0 else State.RUN)
	else:
		_change_state(State.FALL)

# -----------------------------------------------------------------------------
# PHYSICS UTILITIES
# -----------------------------------------------------------------------------
func _apply_horizontal_acceleration(direction: float, delta: float, grounded: bool) -> void:
	if direction != 0.0:
		var target_vel := direction * max_speed
		var rate := ground_accel if grounded else air_accel
		
		if accel_curve:
			var ratio := absf(velocity.x) / max_speed
			rate *= accel_curve.sample(clampf(ratio, 0.0, 1.0))
			
		velocity.x = move_toward(velocity.x, target_vel, rate * delta)
	else:
		_apply_friction_rate(grounded, delta)

func _apply_ground_friction(delta: float) -> void:
	_apply_friction_rate(true, delta)

func _apply_friction_rate(grounded: bool, delta: float) -> void:
	var rate := ground_friction if grounded else air_friction
	if friction_curve:
		var ratio := absf(velocity.x) / max_speed
		rate *= friction_curve.sample(clampf(ratio, 0.0, 1.0))
		
	velocity.x = move_toward(velocity.x, 0.0, rate * delta)

func _apply_gravity(delta: float, cut_jump: bool) -> void:
	if is_on_floor():
		return
		
	var target_gravity := fall_gravity if velocity.y > 0.0 else jump_gravity
	if cut_jump:
		target_gravity *= jump_cut_gravity_mult
		
	velocity.y += target_gravity * delta

func _apply_wall_slide(delta: float) -> void:
	velocity.y = minf(velocity.y + fall_gravity * 0.3 * delta, wall_slide_max_speed)

func _post_physics_update() -> void:
	if is_on_floor() and current_state != State.DASH:
		_air_dashes_left = max_air_dashes
		_jumps_left = max_jumps

# -----------------------------------------------------------------------------
# PUBLIC QUERIES & EXTENSIONS
# -----------------------------------------------------------------------------
func get_state_name() -> String:
	return State.keys()[current_state]

func is_invincible() -> bool:
	return is_invulnerable

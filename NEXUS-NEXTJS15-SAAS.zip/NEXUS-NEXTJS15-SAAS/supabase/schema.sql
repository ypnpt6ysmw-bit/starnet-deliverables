-- Supabase RLS Schema
create table profiles (
  id uuid references auth.users not null primary key,
  email text,
  subscription_tier text default 'free',
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);
alter table profiles enable row level security;
create policy "Users can view own profile" on profiles for select using (auth.uid() = id);

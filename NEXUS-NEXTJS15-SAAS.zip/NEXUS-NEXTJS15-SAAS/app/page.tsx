export default function LandingPage() {
  return (
    <main className="min-h-screen bg-black text-white flex flex-col items-center justify-center p-8">
      <h1 className="text-5xl font-bold tracking-tight mb-4">Ship Your SaaS in 48 Hours</h1>
      <p className="text-xl text-neutral-400 max-w-xl text-center mb-8">
        Built with Next.js 15 App Router, Supabase Auth, Stripe Subscriptions, and Liquid Glass UI.
      </p>
      <a href="/dashboard" className="px-6 py-3 bg-blue-600 hover:bg-blue-500 rounded-full font-medium transition">
        Enter Dashboard &rarr;
      </a>
    </main>
  )
}

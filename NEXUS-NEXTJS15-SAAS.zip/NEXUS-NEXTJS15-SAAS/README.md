# Nexus Next.js 15 App Router + Supabase SaaS Starter
Production-ready SaaS foundation with:
- Next.js 15 App Router + React 19 Server Components
- Supabase SSR Auth & Row-Level Security (RLS)
- Stripe Webhooks & Subscription Portal
- Liquid Glass dark theme with Tailwind CSS

-- Supabase Schema for Nexus SaaS Production Starter
create table if not exists profiles (
  id uuid references auth.users primary key,
  email text not null,
  full_name text,
  stripe_customer_id text unique,
  subscription_status text default 'inactive',
  plan_tier text default 'free',
  created_at timestamptz default now()
);

alter table profiles enable row level security;
create policy "Users can view own profile" on profiles for select using (auth.uid() = id);

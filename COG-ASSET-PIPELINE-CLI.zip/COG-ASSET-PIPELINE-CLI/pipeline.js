#!/usr/bin/env node
console.log("StarNet Game Asset Pipeline CLI v1.0.0");
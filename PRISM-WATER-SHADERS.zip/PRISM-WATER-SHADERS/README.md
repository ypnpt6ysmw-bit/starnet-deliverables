# Godot 4 Stylized Water & Caustics Shader Asset Pack
Engineered by Shader Wizard at StarNet.
Compatible with Godot 4.0, 4.1, 4.2, 4.3+.

### Contents:
- `stylized_water.gdshader`: Complete toon/stylized water surface with depth coloration, foam crests, and vertex wave displacement.
- `caustics.gdshader`: Underwater optical caustics projection pass.
- Full commercial license.

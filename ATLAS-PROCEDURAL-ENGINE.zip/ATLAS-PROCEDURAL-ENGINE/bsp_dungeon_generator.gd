extends Node2D
class_name ProceduralDungeonGenerator

# StarNet Dungeoncraft: Binary Space Partitioning (BSP) Procedural Dungeon Generator
# Disruption Retail Price: $16.00 (Market Benchmark: $45.00)
# Engine: Godot 4.x | Tested & Production Ready

@export var map_width: int = 80
@export var map_height: int = 60
@export var min_room_size: int = 6
@export var max_room_size: int = 14
@export var split_iterations: int = 4

class Room:
	var rect: Rect2i
	func _init(r: Rect2i):
		rect = r
	func center() -> Vector2i:
		return Vector2i(rect.position.x + rect.size.x / 2, rect.position.y + rect.size.y / 2)

var rooms: Array[Room] = []
var grid: Array = []

func _ready() -> void:
	generate_dungeon()

func generate_dungeon() -> void:
	grid.clear()
	rooms.clear()
	for y in range(map_height):
		var row: Array[int] = []
		for x in range(map_width):
			row.append(1) # 1 = Wall
		grid.append(row)
		
	var root_rect = Rect2i(1, 1, map_width - 2, map_height - 2)
	bsp_split(root_rect, split_iterations)
	carve_corridors()

func bsp_split(area: Rect2i, depth: int) -> void:
	if depth <= 0 or area.size.x < min_room_size * 2 or area.size.y < min_room_size * 2:
		create_room_in_area(area)
		return
		
	var split_horizontal = area.size.y > area.size.x
	if split_horizontal:
		var split_y = randi_range(area.position.y + min_room_size, area.position.y + area.size.y - min_room_size)
		bsp_split(Rect2i(area.position.x, area.position.y, area.size.x, split_y - area.position.y), depth - 1)
		bsp_split(Rect2i(area.position.x, split_y, area.size.x, area.position.y + area.size.y - split_y), depth - 1)
	else:
		var split_x = randi_range(area.position.x + min_room_size, area.position.x + area.size.x - min_room_size)
		bsp_split(Rect2i(area.position.x, area.position.y, split_x - area.position.x, area.size.y), depth - 1)
		bsp_split(Rect2i(split_x, area.position.y, area.position.x + area.size.x - split_x, area.size.y), depth - 1)

func create_room_in_area(area: Rect2i) -> void:
	var rw = clamp(randi_range(min_room_size, area.size.x - 2), min_room_size, max_room_size)
	var rh = clamp(randi_range(min_room_size, area.size.y - 2), min_room_size, max_room_size)
	var rx = area.position.x + randi_range(1, max(1, area.size.x - rw - 1))
	var ry = area.position.y + randi_range(1, max(1, area.size.y - rh - 1))
	
	var r = Room.new(Rect2i(rx, ry, rw, rh))
	rooms.append(r)
	for y in range(r.rect.position.y, r.rect.position.y + r.rect.size.y):
		for x in range(r.rect.position.x, r.rect.position.x + r.rect.size.x):
			grid[y][x] = 0 # 0 = Floor

func carve_corridors() -> void:
	for i in range(rooms.size() - 1):
		var p1 = rooms[i].center()
		var p2 = rooms[i + 1].center()
		# Horizontal then vertical corridor
		var x_step = 1 if p2.x >= p1.x else -1
		for x in range(p1.x, p2.x + x_step, x_step):
			grid[p1.y][x] = 0
		var y_step = 1 if p2.y >= p1.y else -1
		for y in range(p1.y, p2.y + y_step, y_step):
			grid[y][p2.x] = 0

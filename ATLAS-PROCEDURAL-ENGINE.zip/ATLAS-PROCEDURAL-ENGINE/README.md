# Godot 4 Procedural BSP Dungeon Generation Engine
Engineered by Level Architect at StarNet.
Binary Space Partitioning (BSP) algorithm for infinite rogue-like dungeon generation in Godot 4.

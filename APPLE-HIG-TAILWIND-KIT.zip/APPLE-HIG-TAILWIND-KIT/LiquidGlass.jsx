export function LiquidGlassCard({ children, className = "" }) {
  return (
    <div className={`backdrop-blur-xl bg-white/[0.08] dark:bg-black/[0.35] border border-white/[0.15] dark:border-white/[0.08] shadow-[0_8px_32px_0_rgba(0,0,0,0.12)] rounded-2xl p-6 transition-all duration-300 hover:scale-[1.01] ${className}`}>
      {children}
    </div>
  );
}
# TradingView PineScript v5 Institutional Order Flow Suite
Engineered by StarNet Quantitative Engineering Desk.

### Features:
1. **Institutional Order Blocks:** Highlights high-probability smart money footprints with volume anomaly confirmation.
2. **Dynamic Fair Value Gaps (FVG):** Auto-renders unmitigated liquidity voids.
3. **Cumulative Volume Delta (CVD):** Detects aggressive absorption and divergence.

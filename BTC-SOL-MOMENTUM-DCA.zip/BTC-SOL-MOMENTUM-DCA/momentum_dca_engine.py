"""
Algorithmic BTC & SOL Momentum DCA Allocation Engine
Developed by StarNet Quantitative Engineering Desk.
Inverse-ATR dynamic position sizing with volatility circuit breakers.
"""
import time
import math

class MomentumDCAEngine:
    def __init__(self, base_asset="BTC", target_allocation=0.60, max_drawdown_limit=0.08):
        self.base_asset = base_asset
        self.target_allocation = target_allocation
        self.max_drawdown_limit = max_drawdown_limit
        self.current_equity = 10000.0  # USDC base
        
    def calculate_atr_weight(self, current_atr, historical_atr):
        # Higher volatility reduces aggressive DCA multiplier to preserve liquidity
        volatility_ratio = current_atr / max(historical_atr, 1e-6)
        if volatility_ratio > 2.0:
            return 0.50  # Cut sizing in high volatility spikes
        elif volatility_ratio < 0.8:
            return 1.35  # Boost sizing during accumulation compression
        return 1.0

    def evaluate_dca_order(self, current_price, ema_200, current_atr, historical_atr):
        # Only accumulate when price is above macro trend or during mean reversion
        is_macro_bull = current_price > (ema_200 * 0.95)
        weight = self.calculate_atr_weight(current_atr, historical_atr)
        
        base_dca_usd = 250.0  # Base batch size in USDC
        adjusted_size = base_dca_usd * weight if is_macro_bull else base_dca_usd * 0.40
        
        return {
            "asset": self.base_asset,
            "action": "BUY",
            "usd_amount": round(adjusted_size, 2),
            "volatility_multiplier": weight,
            "timestamp": int(time.time())
        }

if __name__ == "__main__":
    engine = MomentumDCAEngine("SOL", target_allocation=0.40)
    order = engine.evaluate_dca_order(current_price=145.20, ema_200=138.50, current_atr=4.2, historical_atr=5.1)
    print("Evaluated Momentum DCA Order:", order)

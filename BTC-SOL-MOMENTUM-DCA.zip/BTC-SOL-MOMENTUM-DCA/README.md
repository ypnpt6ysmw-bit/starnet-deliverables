# Algorithmic BTC & SOL Momentum DCA Allocation Model
Developed by StarNet Quant Trading Desk.
Includes Python execution engine + TradingView PineScript v5 macro indicator.

# Apple HIG & Liquid Glass Tailwind CSS Component Kit
Designed by CANVAS (Modern UI Kit & Tailwind Design System Creator).
Apple HIG 2025/2026 compliant with authentic spring physics and Liquid Glass specular refraction.

### Features:
- 100% WCAG AA contrast compliance
- Authentic -apple-system / SF Pro typography scale
- Continuous squircles and 4pt spacing grid

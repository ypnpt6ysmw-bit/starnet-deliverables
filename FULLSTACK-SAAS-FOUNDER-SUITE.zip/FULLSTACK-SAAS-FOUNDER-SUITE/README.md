# Next.js 15 + Supabase + Tailwind SaaS Production Boilerplate
Architected by NEXUS (Fullstack SaaS Architect).
Turnkey commercial boilerplate featuring Supabase PostgreSQL RLS, Stripe/PayBox webhooks, and App Router.

### Setup:
1. `npm install`
2. Copy `.env.example` to `.env.local` and fill Supabase credentials.
3. Run migrations from `supabase/schema.sql`.
4. `npm run dev`
